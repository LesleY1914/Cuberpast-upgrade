// Seleccionar elementos del DOM
const btnAgregarProducto = document.getElementById("btnAgregarProducto");
const modalEliminar = document.getElementById("modalEliminar");
let eliminarTarget = null; 


function abrirModalEliminar() {
  modalEliminar.style.display = "block";
}


function cerrarModal() {
  modalEliminar.style.display = "none";
}


function confirmarModal() {
  if (eliminarTarget) {
    
    eliminarTarget.parentNode.parentNode.remove();
    cerrarModal();
  }
}

// Función para abrir el modal de agregar producto


// Función para preparar la eliminación de un seguimiento
function Eliminar(elemento) {
  abrirModalEliminar();
  eliminarTarget = elemento; // Almacenar el botón que fue clickeado para su uso en confirmarModal
}

// Agregar escuchadores de eventos a los botones de borrar
document.querySelectorAll('.btnBorrar').forEach(btn => {
  btn.addEventListener('click', function() {
    Eliminar(this);
  });
});

// Opcional: Cerrar el modal si se hace clic fuera de él
window.onclick = function(event) {
  if (event.target == modalEliminar) {
    cerrarModal();
  }
}
